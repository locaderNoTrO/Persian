package ir.notro.live

import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat

/** Transparent activity: takes one photo silently with CameraX, saves to Pictures/NoTrO live, closes. */
class CaptureActivity : AppCompatActivity() {
    private var done = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val front = intent.getBooleanExtra("front", false)
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            try {
                val prov = fut.get()
                val ic = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                prov.unbindAll()
                prov.bindToLifecycle(this, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, ic)
                // let auto exposure settle for a moment, then shoot
                window.decorView.postDelayed({ shoot(ic) }, 700)
            } catch (e: Exception) { fin() }
        }, ContextCompat.getMainExecutor(this))
        window.decorView.postDelayed({ fin() }, 8000)
    }

    private fun shoot(ic: ImageCapture) {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "NoTrO_" + System.currentTimeMillis() + ".jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/NoTrO live")
        }
        val o = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        ic.takePicture(o, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { Synth.click(); fin() }
            override fun onError(e: ImageCaptureException) { Synth.error(); fin() }
        })
    }

    private fun fin() { if (!done) { done = true; finish() } }
}
