package ir.notro.live

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import java.util.concurrent.Executors

/** The always-on brain: listens (offline), waits for the wake word, runs commands, speaks. */
class AssistantService : Service(), RecognitionListener {

    companion object {
        @Volatile var status: String = "خاموش"
        @Volatile var running = false
        const val CH = "notro_live"
        const val MODEL_DIR = "model-fa"
    }

    private enum class Mode { IDLE, AWAIT, TYPING }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var speaker: Speaker
    private var model: Model? = null
    private var speech: SpeechService? = null
    private var wake: PowerManager.WakeLock? = null

    @Volatile private var mode = Mode.IDLE
    @Volatile private var awaitUntil = 0L
    @Volatile private var speaking = false
    @Volatile private var scrolling = false
    private var typeBase = ""
    private var lastTyped = ""
    private var lastSleepDay = -1

    @Volatile var pendingSms: Actions.Contact? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_USER_PRESENT) Overlay.unlockEffect(applicationContext)
        }
    }

    // ------------------------------------------------------------ lifecycle
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startFg()
        speaker = Speaker(this)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "notro:live").apply { setReferenceCounted(false); acquire() }
        } catch (e: Exception) {}
        try { registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_USER_PRESENT)) } catch (e: Exception) {}
        Overlay.ensureDot(this)
        main.postDelayed(clock, 20000)
        worker.execute { initModel() }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        scheduleRestart()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        status = "خاموش"
        main.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        try { speech?.shutdown() } catch (e: Exception) {}
        try { model?.close() } catch (e: Exception) {}
        speaker.shutdown()
        try { wake?.release() } catch (e: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun scheduleRestart() {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = if (Build.VERSION.SDK_INT >= 26)
                PendingIntent.getForegroundService(this, 7, Intent(this, AssistantService::class.java), PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE)
            else PendingIntent.getService(this, 7, Intent(this, AssistantService::class.java), PendingIntent.FLAG_ONE_SHOT)
            am.set(AlarmManager.RTC, System.currentTimeMillis() + 1500, pi)
        } catch (e: Exception) {}
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "NoTrO live", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        val n = b.setContentTitle("NoTrO live").setContentText("فعال است — بگو «نوترو»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(11, n)
    }

    // ------------------------------------------------------------ model
    private fun initModel() {
        try {
            status = "در حال آماده‌سازی مدل فارسی…"
            val dir = File(filesDir, MODEL_DIR)
            val ok = File(dir, ".ok")
            if (!ok.exists()) {
                if (assets.list(MODEL_DIR).isNullOrEmpty()) { status = "مدل زبان فارسی داخل برنامه نیست"; return }
                dir.deleteRecursively()
                copyAssets(MODEL_DIR, dir)
                ok.writeText("1")
            }
            model = Model(dir.absolutePath)
            Thread { try { Places.load(applicationContext) } catch (e: Exception) {} }.start()
            main.post { startListening() }
        } catch (e: Throwable) {
            status = "خطا در مدل: " + (e.message ?: "نامشخص")
        }
    }

    private fun copyAssets(path: String, out: File) {
        val list = assets.list(path) ?: return
        if (list.isEmpty()) {
            out.parentFile?.mkdirs()
            assets.open(path).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 16) } }
        } else {
            out.mkdirs()
            for (n in list) copyAssets("$path/$n", File(out, n))
        }
    }

    private fun startListening() {
        try {
            val m = model ?: return
            try { speech?.shutdown() } catch (e: Exception) {}
            val rec = Recognizer(m, 16000.0f)
            speech = SpeechService(rec, 16000.0f).also { it.startListening(this) }
            mode = Mode.IDLE
            status = "فعال — منتظر «نوترو»"
            if (!speaker.persianOk) status += " (صدای فارسی نصب نیست)"
        } catch (e: Throwable) {
            status = "خطا در میکروفون: " + (e.message ?: "")
            main.postDelayed({ startListening() }, 4000)
        }
    }

    // ------------------------------------------------------------ clock: midnight + await timeout
    private val clock = object : Runnable {
        override fun run() {
            try {
                val c = Calendar.getInstance()
                if (c.get(Calendar.HOUR_OF_DAY) == 0 && c.get(Calendar.MINUTE) < 2) {
                    val key = c.get(Calendar.DAY_OF_YEAR)
                    if (lastSleepDay != key) { lastSleepDay = key; say("وقت خوابه نوترو") }
                }
                if (mode == Mode.AWAIT && System.currentTimeMillis() > awaitUntil) { mode = Mode.IDLE; pendingSms = null }
                Overlay.ensureDot(applicationContext)
            } catch (e: Exception) {}
            main.postDelayed(this, 20000)
        }
    }

    // ------------------------------------------------------------ speaking
    fun say(text: String) {
        if (text.isBlank()) return
        main.post {
            speaking = true
            try { speech?.setPause(true) } catch (e: Exception) {}
            speaker.speak(text) {
                main.post {
                    speaking = false
                    try { speech?.setPause(false) } catch (e: Exception) {}
                }
            }
        }
    }

    // ------------------------------------------------------------ recognition callbacks
    private fun textOf(json: String?, key: String): String =
        try { JSONObject(json ?: "{}").optString(key, "") } catch (e: Exception) { "" }

    override fun onPartialResult(h: String?) {
        if (speaking) return
        val p = textOf(h, "partial")
        if (p.isBlank()) return
        when {
            mode == Mode.TYPING -> typeLive(p)
            scrolling -> if (stopWord(p)) stopScroll()
        }
    }

    override fun onResult(h: String?) { process(textOf(h, "text")) }
    override fun onFinalResult(h: String?) { process(textOf(h, "text")) }
    override fun onError(e: Exception?) { status = "خطای شنیدن؛ دوباره تلاش می‌کنم"; main.postDelayed({ startListening() }, 1500) }
    override fun onTimeout() { startListening() }

    private fun stopWord(t: String): Boolean {
        val w = Fa.words(t)
        return w.any { it in setOf("وایسا", "وایستا", "بایست", "ایست", "توقف", "بس", "بسه", "استپ", "ایستا", "وایس") }
    }

    private fun process(raw: String) {
        if (speaking || raw.isBlank()) return
        val t = Fa.norm(raw)
        worker.execute {
            try { route(t) } catch (e: Throwable) { say("یه مشکلی پیش اومد ولی ادامه می‌دم") }
        }
    }

    private fun route(t: String) {
        if (scrolling) { if (stopWord(t)) stopScroll(); return }
        if (mode == Mode.TYPING) { finishTyping(t); return }

        val now = System.currentTimeMillis()
        val wakeRest = Wake.strip(t)
        val awaiting = mode == Mode.AWAIT && now < awaitUntil
        if (wakeRest == null && !awaiting) return          // not for me: stay silent

        val cmd = wakeRest ?: t
        val pend = pendingSms
        if (pend != null && awaiting) {
            pendingSms = null
            mode = Mode.IDLE
            Synth.ack()
            say(Brain.sendPending(this, pend, cmd))
            return
        }
        if (cmd.isBlank()) {
            mode = Mode.AWAIT
            awaitUntil = now + 9000
            Synth.ack()
            say("بله جناب نوترو")
            return
        }
        mode = Mode.IDLE
        Synth.ack()
        val reply = Brain.handle(this, cmd)
        if (pendingSms != null) { mode = Mode.AWAIT; awaitUntil = System.currentTimeMillis() + 12000 }
        if (reply.isNotBlank()) say(reply)
    }

    // ------------------------------------------------------------ scroll
    fun startScroll(down: Boolean) {
        val a = NotroAccess.inst ?: return
        scrolling = true
        Thread {
            while (scrolling && running) {
                a.swipe(down)
                try { Thread.sleep(850) } catch (e: Exception) {}
            }
        }.start()
    }

    private fun stopScroll() {
        scrolling = false
        Synth.click()
        say("وایسادم")
    }

    // ------------------------------------------------------------ live typing
    fun startTyping(first: String) {
        val a = NotroAccess.inst ?: return
        typeBase = a.fieldText()
        lastTyped = ""
        mode = Mode.TYPING
        if (first.isNotBlank()) typeLive(first)
    }

    private fun typeLive(partial: String) {
        val a = NotroAccess.inst ?: return
        val p = Fa.norm(partial)
        if (p == lastTyped) return
        lastTyped = p
        worker.execute { a.setFieldText(join(typeBase, p)) }
    }

    private fun join(base: String, add: String) = if (base.isBlank()) add else base.trimEnd() + " " + add

    private fun finishTyping(t: String) {
        val a = NotroAccess.inst
        val w = Fa.words(t)
        val end = w.isNotEmpty() && w.last() in setOf("تمام", "تمامه", "پایان", "تمومه", "تموم")
        val body = (if (end) w.dropLast(1) else w).joinToString(" ")
        val text = Fa.formalize(body)
        if (a != null && text.isNotBlank()) {
            typeBase = join(typeBase, text)
            a.setFieldText(typeBase)
            lastTyped = ""
        }
        if (end) {
            mode = Mode.IDLE
            Synth.ack()
            say("تایپ تموم شد")
        }
    }

    // ------------------------------------------------------------ camera
    fun capture(front: Boolean) {
        val i = Intent(this, CaptureActivity::class.java).putExtra("front", front)
        Actions.launch(applicationContext, i)
    }

    // ------------------------------------------------------------ location
    fun where() {
        say("باشه، دارم موقعیتت رو پیدا می‌کنم")
        Actions.locate(applicationContext) { loc ->
            if (loc == null) say("نتونستم جی‌پی‌اس رو بگیرم. مطمئن شو موقعیت مکانی گوشی روشنه و بیرون یا کنار پنجره باشی.")
            else worker.execute { say(Places.describe(applicationContext, loc.latitude, loc.longitude)) }
        }
    }
}
