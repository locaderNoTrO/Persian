package ir.notro.live

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

class AboutActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(28)); setBackgroundColor(BG) }
        col.addView(label("درباره‌ی ما", 26f, DEEP, true))
        col.addView(label("NoTrO live", 20f, INK, true))

        fun sec(title: String, body: String) {
            val c = card()
            c.addView(label(title, 17f, DEEP, true))
            c.addView(label(body, 15f))
            col.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        }
        sec("معرفی",
            "نوترو لایو یک دستیار صوتی فارسی و کاملاً آفلاین برای اندروید است. وقتی نامش را صدا می‌زنید (نوترو، نوترون یا سرهنگ) پاسخ می‌دهد «بله جناب نوترو» و دستور شما را اجرا می‌کند؛ حتی وقتی صفحه خاموش یا قفل است.")
        sec("نقاط قوت",
            "• کاملاً آفلاین: بدون اینترنت و بدون ارسال صدا به جایی\n• فهم فارسی رسمی و محاوره‌ای\n• تماس، پیامک با سیم‌کارت یک، خواندن آخرین پیام\n• باز کردن برنامه‌ها با نام فارسی یا انگلیسی\n• روشن و خاموش کردن اینترنت، بلوتوث، چراغ قوه، حالت هواپیما و کانون داغ\n• تایپ زنده کلمه‌به‌کلمه، اسکرول، اسکرین‌شات، عکس و سلفی\n• موقعیت‌یابی آفلاین: کشور، استان، شهرستان، شهر، خیابان و کوچه\n• گفتگوی دوستانه، جوک و احساسات\n• افکت مکانیکی هنگام باز شدن قفل")
        sec("طرز استفاده",
            "۱. در صفحه‌ی اصلی همه‌ی مجوزها و دسترسی‌ها را بدهید.\n۲. دکمه‌ی «روشن کردن» را بزنید.\n۳. بگویید «نوترو» و منتظر «بله جناب نوترو» بمانید، سپس دستور بدهید؛ یا مستقیم بگویید «نوترو، ساعت چنده».\n\nمثال‌ها:\n• نوترو زنگ بزن به علی\n• نوترو پیام بده به مامان سلام خوبی\n• نوترو دوربین رو باز کن\n• نوترو چراغ قوه روشن کن\n• نوترو برو پایین … وایسا\n• نوترو تایپ کن … تمام\n• نوترو من کجا هستم\n• نوترو شلیک")
        sec("سازنده", "امیرمهدی احمدی ملقب به نوترو")
        val back = neonButton("بازگشت")
        back.setOnClickListener { finish() }
        col.addView(back, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        setContentView(ScrollView(this).apply { addView(col); setBackgroundColor(BG) })
    }
}
