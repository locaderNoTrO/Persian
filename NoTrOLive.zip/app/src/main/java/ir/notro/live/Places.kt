package ir.notro.live

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Fully offline reverse geocoder for Iran + Iraq.
 * admin.json  : simplified province / county polygons (built from OpenStreetMap while building the APK)
 * places.db   : cities, villages, neighbourhoods and named roads (same source)
 */
object Places {
    private class Poly(val level: Int, val country: String, val name: String, val b: DoubleArray, val rings: List<DoubleArray>)

    private var polys: List<Poly>? = null
    private var db: SQLiteDatabase? = null
    @Volatile var available = false

    private fun copyAsset(ctx: Context, name: String, out: File) {
        if (out.exists() && out.length() > 0) return
        val tmp = File(out.path + ".tmp")
        ctx.assets.open(name).use { i -> FileOutputStream(tmp).use { o -> i.copyTo(o, 1 shl 16) } }
        tmp.renameTo(out)
    }

    @Synchronized
    fun load(ctx: Context): Boolean {
        if (polys != null && db != null) return true
        try {
            val names = ctx.assets.list("")?.toSet() ?: emptySet()
            if ("admin.json" !in names && "places.db" !in names) return false
            if ("admin.json" in names) {
                val txt = ctx.assets.open("admin.json").bufferedReader().use { it.readText() }
                val arr = JSONArray(txt)
                val list = ArrayList<Poly>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val bb = o.getJSONArray("b")
                    val b = DoubleArray(4) { bb.getDouble(it) }
                    val rs = o.getJSONArray("r")
                    val rings = ArrayList<DoubleArray>()
                    for (k in 0 until rs.length()) {
                        val ra = rs.getJSONArray(k)
                        rings.add(DoubleArray(ra.length()) { ra.getDouble(it) })
                    }
                    list.add(Poly(o.getInt("l"), o.getString("c"), o.getString("n"), b, rings))
                }
                polys = list
            } else polys = emptyList()
            if ("places.db" in names) {
                val f = File(ctx.filesDir, "places.db")
                copyAsset(ctx, "places.db", f)
                db = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
            }
            available = true
            return true
        } catch (e: Throwable) {
            return false
        }
    }

    private fun inside(p: Poly, lat: Double, lon: Double): Boolean {
        val b = p.b
        if (lon < b[0] || lon > b[2] || lat < b[1] || lat > b[3]) return false
        var c = false
        for (r in p.rings) {
            val n = r.size / 2
            var j = n - 1
            for (i in 0 until n) {
                val xi = r[2 * i]; val yi = r[2 * i + 1]
                val xj = r[2 * j]; val yj = r[2 * j + 1]
                if ((yi > lat) != (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) c = !c
                j = i
            }
        }
        return c
    }

    private fun dist(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dy = (lat1 - lat2) * 111000.0
        val dx = (lon1 - lon2) * 111000.0 * cos(Math.toRadians(lat1))
        return sqrt(dx * dx + dy * dy)
    }

    private class Hit(val name: String, val kind: String, val d: Double)

    private fun query(lat: Double, lon: Double, box: Double, table: String): List<Hit> {
        val d = db ?: return emptyList()
        val res = ArrayList<Hit>()
        val sql = if (table == "places")
            "SELECT name,kind,lat,lon FROM places WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?"
        else "SELECT name,kind,lat,lon FROM roads WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?"
        try {
            d.rawQuery(sql, arrayOf((lat - box).toString(), (lat + box).toString(), (lon - box).toString(), (lon + box).toString())).use { c ->
                while (c.moveToNext()) {
                    res.add(Hit(c.getString(0), c.getString(1), dist(lat, lon, c.getDouble(2), c.getDouble(3))))
                }
            }
        } catch (e: Exception) {}
        return res.sortedBy { it.d }
    }

    /** Spoken description, from the biggest unit to the smallest one. */
    fun describe(ctx: Context, lat: Double, lon: Double): String {
        if (!load(ctx)) return "نقشه‌ی آفلاین داخل برنامه نیست، ولی مختصات شما ${"%.4f".format(lat)} و ${"%.4f".format(lon)} است"
        val parts = ArrayList<String>()
        var country: String? = null
        var province: String? = null
        var county: String? = null
        for (p in polys ?: emptyList()) {
            if (p.level == 4 && province == null && inside(p, lat, lon)) { province = p.name; country = p.country }
            if (p.level == 5 && county == null && inside(p, lat, lon)) { county = p.name; if (country == null) country = p.country }
        }
        if (country == null) return "به نظر می‌رسد خارج از نقشه‌ی ایران و عراق هستید. مختصات شما ${"%.4f".format(lat)} و ${"%.4f".format(lon)} است"
        parts.add("کشور " + if (country == "IR") "ایران" else "عراق")
        if (province != null) parts.add((if (country == "IR") "استان " else "استان ") + province)
        if (county != null && county != province) parts.add("شهرستان " + county)

        val pl = query(lat, lon, 0.2, "places")
        val city = pl.firstOrNull { it.kind == "city" || it.kind == "town" || it.kind == "village" || it.kind == "hamlet" }
        if (city != null && city.d < 15000) parts.add((if (city.kind == "village" || city.kind == "hamlet") "روستای " else "شهر ") + city.name)
        val hood = pl.firstOrNull { (it.kind == "suburb" || it.kind == "neighbourhood") && it.d < 3000 }
        if (hood != null) parts.add("محله‌ی " + hood.name)

        val rd = query(lat, lon, 0.004, "roads")
        val major = rd.firstOrNull { it.kind == "major" && it.d < 400 }
        val minor = rd.firstOrNull { it.kind == "minor" && it.d < 150 }
        if (major != null) parts.add("خیابان " + major.name)
        if (minor != null && (major == null || minor.name != major.name)) parts.add("کوچه " + minor.name)
        return "شما در " + parts.joinToString("، ") + " هستید"
    }
}
