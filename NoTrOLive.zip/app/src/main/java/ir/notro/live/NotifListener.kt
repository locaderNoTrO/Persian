package ir.notro.live

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Remembers the newest message notification so the assistant can read it aloud. */
class NotifListener : NotificationListenerService() {
    companion object {
        @Volatile var lastTitle: String = ""
        @Volatile var lastText: String = ""
        @Volatile var lastTime: Long = 0
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn?.notification ?: return
        val isMsg = n.category == Notification.CATEGORY_MESSAGE ||
            sbn.packageName.contains("messaging") || sbn.packageName.contains("sms") || sbn.packageName.contains("mms")
        if (!isMsg) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.isBlank()) return
        lastTitle = title
        lastText = text
        lastTime = System.currentTimeMillis()
    }
}
