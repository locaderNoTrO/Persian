package ir.notro.live

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        try { startAssistant(ctx) } catch (e: Exception) {}
    }
}
