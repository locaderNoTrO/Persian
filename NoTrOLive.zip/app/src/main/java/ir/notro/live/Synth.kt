package ir.notro.live

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Small procedural sound effects (mechanical / sci-fi), generated at runtime, no audio files needed. */
object Synth {
    private const val SR = 22050
    private val main = Handler(Looper.getMainLooper())

    private fun play(pcm: ShortArray, onDone: (() -> Unit)? = null) {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            val t = AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(fmt)
                .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
            t.write(pcm, 0, pcm.size)
            t.play()
            val ms = pcm.size * 1000L / SR + 200
            main.postDelayed({
                try { t.stop() } catch (e: Exception) {}
                t.release()
                onDone?.invoke()
            }, ms)
        } catch (e: Exception) {
            onDone?.invoke()
        }
    }

    private fun buf(sec: Double) = DoubleArray((sec * SR).toInt())

    private fun toPcm(d: DoubleArray, gain: Double = 1.0): ShortArray =
        ShortArray(d.size) { (d[it] * gain * 30000).coerceIn(-32000.0, 32000.0).toInt().toShort() }

    /** Rising mechanical charge-up whine (used by "شلیک"). */
    fun charge(sec: Double = 3.0) {
        val d = buf(sec)
        var ph = 0.0
        var ph2 = 0.0
        for (i in d.indices) {
            val t = i.toDouble() / d.size
            val f = 90.0 + 1900.0 * t * t
            ph += 2 * PI * f / SR
            ph2 += 2 * PI * (f * 2.01) / SR
            val saw = ((ph / (2 * PI)) % 1.0) * 2 - 1
            val a = 0.15 + 0.65 * t
            d[i] = (saw * 0.5 + sin(ph2) * 0.25 + (Random.nextDouble() - .5) * 0.15 * t) * a
        }
        play(toPcm(d))
    }

    /** Big mechanical blast. */
    fun blast(sec: Double = 2.0) {
        val d = buf(sec)
        for (i in d.indices) {
            val t = i.toDouble() / SR
            val thump = sin(2 * PI * (70.0 - 30 * t) * t) * exp(-t * 3.2)
            val noise = (Random.nextDouble() - .5) * exp(-t * 6.0)
            val metal = sin(2 * PI * 880 * t) * exp(-t * 7) * .35 + sin(2 * PI * 2430 * t) * exp(-t * 9) * .2
            d[i] = (thump * .9 + noise * .8 + metal)
        }
        play(toPcm(d))
    }

    /** Iron-Man-like unlock: servo whirr, click, rising chime. */
    fun unlock() {
        val d = buf(1.6)
        var ph = 0.0
        for (i in d.indices) {
            val t = i.toDouble() / SR
            var v = 0.0
            if (t < .7) {
                val f = 140 + 700 * (t / .7)
                ph += 2 * PI * f / SR
                v += (((ph / (2 * PI)) % 1.0) * 2 - 1) * .25 * (t / .7)
                v += (Random.nextDouble() - .5) * .06
            }
            if (t in .7..0.78) v += (Random.nextDouble() - .5) * exp(-(t - .7) * 90) * 1.2
            if (t > .75) {
                val tt = t - .75
                v += sin(2 * PI * 1320 * tt) * exp(-tt * 4) * .35 + sin(2 * PI * 1980 * tt) * exp(-tt * 5) * .25
            }
            d[i] = v
        }
        play(toPcm(d))
    }

    fun ack() {
        val d = buf(.18)
        for (i in d.indices) {
            val t = i.toDouble() / SR
            d[i] = sin(2 * PI * (700 + 900 * t / .18) * t) * exp(-t * 14) * .6
        }
        play(toPcm(d))
    }

    fun click() {
        val d = buf(.08)
        for (i in d.indices) {
            val t = i.toDouble() / SR
            d[i] = (Random.nextDouble() - .5) * exp(-t * 70) + sin(2 * PI * 1800 * t) * exp(-t * 60) * .5
        }
        play(toPcm(d))
    }

    fun error() {
        val d = buf(.3)
        for (i in d.indices) {
            val t = i.toDouble() / SR
            d[i] = sin(2 * PI * 180 * t) * exp(-t * 6) * .5 + sin(2 * PI * 140 * t) * exp(-t * 8) * .4
        }
        play(toPcm(d))
    }
}
