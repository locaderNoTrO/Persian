package ir.notro.live

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Green "ground" dot on the home screen + the Iron-Man style unlock effect. */
object Overlay {
    private const val GREEN = 0xFF39FF14.toInt()
    private val h = Handler(Looper.getMainLooper())
    private var dot: View? = null
    private var fx: View? = null

    private class DotView(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val t0 = System.currentTimeMillis()
        override fun onDraw(cv: Canvas) {
            val t = (System.currentTimeMillis() - t0) / 1000.0
            val r = min(width, height) / 2f
            p.style = Paint.Style.FILL
            p.color = GREEN
            p.alpha = 70
            cv.drawCircle(width / 2f, height / 2f, r * (0.8f + 0.2f * sin(t * 3).toFloat()), p)
            p.alpha = 255
            cv.drawCircle(width / 2f, height / 2f, r * 0.5f, p)
            postInvalidateOnAnimation()
        }
    }

    private class FxView(c: Context) : View(c) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var k = 0f
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat(); val hgt = height.toFloat()
            val cx = w / 2; val cy = hgt / 2
            val maxR = max(w, hgt) * 0.75f
            p.style = Paint.Style.FILL
            p.color = Color.BLACK
            p.alpha = (150 * (1 - k)).toInt().coerceIn(0, 255)
            cv.drawRect(0f, 0f, w, hgt, p)
            p.style = Paint.Style.STROKE
            p.color = GREEN
            val fade = (255 * (1 - k * k)).toInt().coerceIn(0, 255)
            // expanding rings
            for (i in 0..2) {
                val kk = (k * 1.25f - i * 0.12f).coerceIn(0f, 1f)
                p.alpha = (fade * (1 - kk)).toInt().coerceIn(0, 255)
                p.strokeWidth = 5f + 6f * (1 - kk)
                cv.drawCircle(cx, cy, maxR * kk, p)
            }
            // rotating reactor segments
            p.alpha = fade
            p.strokeWidth = 14f
            val r1 = min(w, hgt) * 0.2f
            val rect = RectF(cx - r1, cy - r1, cx + r1, cy + r1)
            for (i in 0 until 3) cv.drawArc(rect, k * 540f + i * 120f, 80f, false, p)
            p.strokeWidth = 5f
            val r2 = r1 * 1.45f
            val rect2 = RectF(cx - r2, cy - r2, cx + r2, cy + r2)
            for (i in 0 until 6) cv.drawArc(rect2, -k * 360f + i * 60f, 30f, false, p)
            p.style = Paint.Style.FILL
            p.alpha = (fade * 0.8f).toInt()
            cv.drawCircle(cx, cy, r1 * 0.35f * (0.6f + 0.4f * sin(k * 20f)), p)
            // scan line
            p.alpha = (fade * 0.7f).toInt()
            cv.drawRect(0f, hgt * k - 3f, w, hgt * k + 3f, p)
            p.textSize = 34f
            p.textAlign = Paint.Align.CENTER
            cv.drawText("NoTrO LIVE  //  ONLINE", cx, cy + r2 + 70f, p)
        }
    }

    fun canDraw(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun ensureDot(ctx: Context) {
        h.post {
            if (dot != null || !canDraw(ctx)) return@post
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val v = DotView(ctx.applicationContext)
                val s = ctx.dp(9)
                val lp = WindowManager.LayoutParams(
                    s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                lp.y = ctx.dp(8)
                v.alpha = 0f
                wm.addView(v, lp)
                dot = v
            } catch (e: Exception) {}
        }
    }

    fun setHome(on: Boolean) {
        h.post { dot?.animate()?.alpha(if (on) 1f else 0f)?.setDuration(250)?.start() }
    }

    fun unlockEffect(ctx: Context) {
        Synth.unlock()
        h.post {
            if (!canDraw(ctx) || fx != null) return@post
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val v = FxView(ctx.applicationContext)
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                wm.addView(v, lp)
                fx = v
                val a = ValueAnimator.ofFloat(0f, 1f)
                a.duration = 1600
                a.addUpdateListener { v.k = it.animatedValue as Float; v.invalidate() }
                a.addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(an: android.animation.Animator) {
                        try { wm.removeView(v) } catch (e: Exception) {}
                        fx = null
                    }
                })
                a.start()
            } catch (e: Exception) { fx = null }
        }
    }
}
