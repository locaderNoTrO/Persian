package ir.notro.live

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.File
import java.io.FileOutputStream

/** Persian voice bundled inside the app (Piper "amir" through sherpa-onnx). Needs no Google, no internet. */
object SherpaVoice {
    @Volatile var ready = false
    @Volatile private var failed = false
    @Volatile var error = ""
    private var tts: OfflineTts? = null
    @Volatile private var track: AudioTrack? = null
    private const val DIR = "tts-fa"

    @Synchronized
    fun init(ctx: Context) {
        if (ready || failed) return
        try {
            val am = ctx.assets
            if (am.list(DIR).isNullOrEmpty()) { failed = true; error = "مدل صدا داخل APK نیست"; return }
            val dir = File(ctx.filesDir, DIR)
            val ok = File(dir, ".ok")
            if (!ok.exists()) {
                dir.deleteRecursively()
                copy(ctx, DIR, dir)
                ok.writeText("1")
            }
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    vits = OfflineTtsVitsModelConfig(
                        model = File(dir, "model.onnx").absolutePath,
                        tokens = File(dir, "tokens.txt").absolutePath,
                        dataDir = File(dir, "espeak-ng-data").absolutePath
                    ),
                    numThreads = 2, debug = false, provider = "cpu"
                )
            )
            tts = OfflineTts(null, cfg)
            ready = true
        } catch (e: Throwable) {
            failed = true
            error = e.javaClass.simpleName + ": " + (e.message ?: "")
        }
    }

    private fun copy(ctx: Context, path: String, out: File) {
        val list = ctx.assets.list(path) ?: return
        if (list.isEmpty()) {
            out.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> FileOutputStream(out).use { o -> i.copyTo(o, 1 shl 16) } }
        } else {
            out.mkdirs()
            for (n in list) copy(ctx, "$path/$n", File(out, n))
        }
    }

    private fun clean(t: String): String =
        t.replace("«", " ").replace("»", " ").replace("‌", " ").replace(Regex("\\s+"), " ").trim()

    /** Blocks until the sentence has been played (call from a worker thread). */
    fun speakBlocking(text: String) {
        val t = tts ?: return
        val a = t.generate(clean(text), 0, 1.0f)
        val s = a.samples
        if (s.isEmpty()) return
        val pcm = ShortArray(s.size) { (s[it].coerceIn(-1f, 1f) * 32000).toInt().toShort() }
        val rate = (a.sampleRate * 0.9).toInt()           // a bit slower and deeper
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        track = tr
        tr.write(pcm, 0, pcm.size)
        tr.play()
        val ms = pcm.size * 1000L / rate + 150
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end && track === tr) Thread.sleep(40)
        try { tr.stop() } catch (e: Exception) {}
        tr.release()
        if (track === tr) track = null
    }

    fun stop() { val t = track; track = null; try { t?.stop() } catch (e: Exception) {} }
}
