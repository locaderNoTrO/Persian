package ir.notro.live

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var statusTv: TextView
    private lateinit var toggle: android.widget.Button
    private val rows = ArrayList<Pair<TextView, () -> Boolean>>()
    private val h = Handler(Looper.getMainLooper())

    /** Light pulse: one animated circle, redrawn at ~30 fps only while visible. */
    private inner class Pulse : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val t0 = System.currentTimeMillis()
        override fun onDraw(c: Canvas) {
            val t = (System.currentTimeMillis() - t0) / 1000.0
            val cx = width / 2f; val cy = height / 2f
            val on = AssistantService.running
            val r = minOf(width, height) / 2f
            for (i in 3 downTo 0) {
                val k = if (on) (0.55f + 0.08f * i + 0.04f * sin(t * 2.2 + i).toFloat()) else (0.45f + 0.05f * i)
                p.color = ACID; p.alpha = (50 + 40 * (3 - i)) / (if (on) 1 else 2)
                c.drawCircle(cx, cy, r * k, p)
            }
            p.color = DEEP; p.alpha = 255
            c.drawCircle(cx, cy, r * 0.22f, p)
            postInvalidateDelayed(33)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(30), dp(18), dp(30)); setBackgroundColor(BG) }
        col.addView(label("NoTrO live", 30f, DEEP, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER })
        col.addView(label("دستیار صوتی فارسی و آفلاین", 15f).apply { textAlignment = View.TEXT_ALIGNMENT_CENTER })
        col.addView(Pulse(), LinearLayout.LayoutParams(-1, dp(190)))
        statusTv = label("", 16f, INK, true).apply { textAlignment = View.TEXT_ALIGNMENT_CENTER }
        col.addView(statusTv)
        toggle = neonButton("روشن کردن", 20f)
        toggle.setOnClickListener {
            if (AssistantService.running) { stopService(Intent(this, AssistantService::class.java)) }
            else if (!has(Manifest.permission.RECORD_AUDIO)) { askPerms(); Toast.makeText(this, "اول مجوزها رو بده", Toast.LENGTH_SHORT).show() }
            else startAssistant(this)
            h.postDelayed({ refresh() }, 600)
        }
        col.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        val setup = card()
        setup.addView(label("آماده‌سازی (همه را سبز کن)", 17f, DEEP, true))
        col.addView(setup, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        row(setup, "مجوزهای اصلی (میکروفون، تماس، پیامک، مخاطبین، دوربین، موقعیت)", { allPerms() }) { askPerms() }
        row(setup, "موقعیت مکانی «همیشه» (برای کار با صفحه‌ی خاموش)", { Build.VERSION.SDK_INT < 29 || has(Manifest.permission.ACCESS_BACKGROUND_LOCATION) }) {
            if (Build.VERSION.SDK_INT >= 29) requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        }
        row(setup, "سرویس دسترسی‌پذیری NoTrO (اسکرول، تایپ، قفل، اسکرین‌شات، حالت هواپیما)", { NotroAccess.inst != null }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "NoTrO live را پیدا کن و روشن کن", Toast.LENGTH_LONG).show()
        }
        row(setup, "دسترسی به اعلان‌ها (خواندن آخرین پیام)", { notifOn() }) {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        row(setup, "نمایش روی برنامه‌ها (نقطه‌ی سبز و افکت قفل)", { Overlay.canDraw(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        row(setup, "بدون محدودیت باتری (برای همیشه روشن ماندن)", { batteryOk() }) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        row(setup, "شیائومی: شروع خودکار (Autostart) را روشن کن و باتری را روی «بدون محدودیت» بگذار", { false }) { miui() }
        row(setup, "صدای فارسی گوشی (برای پاسخ دادن با صدا)", { ttsOk }) {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (e: Exception) {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) {}
            }
            Toast.makeText(this, "موتور گوگل را انتخاب و داده‌ی «فارسی» را دانلود کن", Toast.LENGTH_LONG).show()
        }
        val about = neonButton("درباره‌ی ما", 17f, false)
        about.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }
        col.addView(about, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        setContentView(ScrollView(this).apply { addView(col); setBackgroundColor(BG) })
        checkTts()
    }

    @Volatile private var ttsOk = false
    private fun checkTts() {
        var t: android.speech.tts.TextToSpeech? = null
        t = android.speech.tts.TextToSpeech(applicationContext) { st ->
            if (st == android.speech.tts.TextToSpeech.SUCCESS) {
                val r = t?.isLanguageAvailable(java.util.Locale("fa", "IR")) ?: -2
                ttsOk = r >= android.speech.tts.TextToSpeech.LANG_AVAILABLE
            }
            try { t?.shutdown() } catch (e: Exception) {}
            runOnUiThread { refresh() }
        }
    }

    private fun row(parent: LinearLayout, text: String, ok: () -> Boolean, act: () -> Unit) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(2)) }
        val dot = label("●", 20f, 0xFFD32F2F.toInt(), true)
        val tv = label(text, 14f).apply { setPadding(dp(8), 0, dp(8), 0) }
        val bt = neonButton("بده", 14f)
        bt.setPadding(dp(12), dp(4), dp(12), dp(4))
        bt.setOnClickListener { act() }
        r.addView(dot); r.addView(tv, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(bt)
        parent.addView(r)
        rows.add(Pair(dot, ok))
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
    )
    private fun allPerms() = perms.all { has(it) }
    private fun askPerms() { requestPermissions(perms.filter { !has(it) }.toTypedArray().ifEmpty { perms }, 1) }
    private fun notifOn() = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
    private fun batteryOk() = try { (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName) } catch (e: Exception) { false }

    private fun miui() {
        val tries = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent().setComponent(ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")).putExtra("package_name", packageName).putExtra("package_label", "NoTrO live"),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
        for (i in tries) { try { startActivity(i); break } catch (e: Exception) {} }
        Toast.makeText(this, "Autostart را روشن کن و باتری را «بدون محدودیت» بگذار", Toast.LENGTH_LONG).show()
    }

    override fun onResume() { super.onResume(); refresh(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(c, p, g); refresh() }

    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1500) } }

    private fun refresh() {
        statusTv.text = if (AssistantService.running) AssistantService.status else "خاموش"
        toggle.text = if (AssistantService.running) "خاموش کردن" else "روشن کردن"
        for ((dot, ok) in rows) dot.setTextColor(if (ok()) 0xFF2E9E00.toInt() else 0xFFD32F2F.toInt())
    }
}
