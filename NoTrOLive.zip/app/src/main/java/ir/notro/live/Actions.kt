package ir.notro.live

import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

object Actions {

    fun launch(ctx: Context, i: Intent) {
        val a = NotroAccess.inst
        if (a != null) a.launch(i) else {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    // ---------------- contacts ----------------
    class Contact(val name: String, val number: String, val norm: String)

    private var cache: List<Contact> = emptyList()
    private var cacheT = 0L

    fun contacts(ctx: Context): List<Contact> {
        if (System.currentTimeMillis() - cacheT < 60000 && cache.isNotEmpty()) return cache
        val out = ArrayList<Contact>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val p = c.getString(1) ?: continue
                    out.add(Contact(n, p, Fa.norm(n)))
                }
            }
        } catch (e: Exception) {}
        cache = out
        cacheT = System.currentTimeMillis()
        return out
    }

    /** Finds the contact whose name is spoken in the first 1..3 words. Returns contact and how many words it used. */
    fun matchContact(ctx: Context, words: List<String>): Pair<Contact, Int>? {
        val list = contacts(ctx)
        if (list.isEmpty() || words.isEmpty()) return null
        var best: Contact? = null
        var bs = 0.0
        var bk = 0
        for (k in 1..minOf(3, words.size)) {
            val cand = words.take(k).joinToString(" ")
            for (c in list) {
                var s = Fa.sim(cand, c.norm)
                val toks = c.norm.split(" ")
                if (toks.firstOrNull() == cand) s = maxOf(s, 0.93)
                if (c.norm.contains(cand) && cand.length >= 3) s = maxOf(s, 0.86)
                if (cand.contains(c.norm) && c.norm.length >= 3) s = maxOf(s, 0.88)
                if (s > bs + 0.001 || (s >= bs - 0.02 && k > bk && s >= 0.85)) { bs = s; best = c; bk = k }
            }
        }
        return if (best != null && bs >= 0.62) Pair(best, bk) else null
    }

    fun call(ctx: Context, number: String) {
        launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
    }

    @Suppress("DEPRECATION")
    fun sendSms(ctx: Context, number: String, text: String): Boolean {
        return try {
            var sm: SmsManager = SmsManager.getDefault()
            try {
                val sub = ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                val info = sub.getActiveSubscriptionInfoForSimSlotIndex(0)
                if (info != null) sm = SmsManager.getSmsManagerForSubscriptionId(info.subscriptionId)
            } catch (e: Exception) {}
            val parts = sm.divideMessage(text)
            if (parts.size > 1) sm.sendMultipartTextMessage(number, null, parts, null, null)
            else sm.sendTextMessage(number, null, text, null, null)
            true
        } catch (e: Exception) { false }
    }

    private fun nameForNumber(ctx: Context, number: String): String? {
        return try {
            ctx.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) { null }
    }

    /** Newest message: from the SMS inbox, or from the last message notification. */
    fun latestMessage(ctx: Context): String? {
        try {
            ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body", "date"), null, null, "date DESC LIMIT 1"
            )?.use { c ->
                if (c.moveToFirst()) {
                    val addr = c.getString(0) ?: ""
                    val body = c.getString(1) ?: ""
                    val who = nameForNumber(ctx, addr) ?: addr
                    return "پیام از $who. $body"
                }
            }
        } catch (e: Exception) {}
        if (NotifListener.lastText.isNotBlank()) {
            return "پیام از ${NotifListener.lastTitle}. ${NotifListener.lastText}"
        }
        return null
    }

    // ---------------- flashlight ----------------
    private fun torchId(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            val ch = cm.getCameraCharacteristics(id)
            if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            ) return id
        }
        return null
    }

    fun torch(ctx: Context, on: Boolean): Boolean {
        return try {
            val id = torchId(ctx) ?: return false
            (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(id, on)
            true
        } catch (e: Exception) { false }
    }

    /** "شلیک": soft glow rising to maximum over 3 s, off, then full power for 2 s. */
    fun shoot(ctx: Context) {
        Thread {
            try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = torchId(ctx)
                if (id == null) { Synth.charge(3.0); Thread.sleep(3300); Synth.blast(2.0); return@Thread }
                var max = 1
                if (Build.VERSION.SDK_INT >= 33) {
                    max = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                }
                Synth.charge(3.0)
                val t0 = System.currentTimeMillis()
                while (true) {
                    val el = System.currentTimeMillis() - t0
                    if (el >= 3000) break
                    val frac = el / 3000.0
                    if (max > 1 && Build.VERSION.SDK_INT >= 33) {
                        val lv = (1 + (max - 1) * frac).toInt().coerceIn(1, max)
                        try { cm.turnOnTorchWithStrengthLevel(id, lv) } catch (e: Exception) { cm.setTorchMode(id, true) }
                        Thread.sleep(100)
                    } else {
                        // no brightness levels on this phone: fast flicker with a growing duty cycle
                        val on = (40 * frac).toLong().coerceAtLeast(1)
                        cm.setTorchMode(id, true); Thread.sleep(on)
                        cm.setTorchMode(id, false); Thread.sleep(40 - on + 1)
                    }
                }
                cm.setTorchMode(id, false)
                Thread.sleep(350)
                Synth.blast(2.0)
                if (max > 1 && Build.VERSION.SDK_INT >= 33) {
                    try { cm.turnOnTorchWithStrengthLevel(id, max) } catch (e: Exception) { cm.setTorchMode(id, true) }
                } else cm.setTorchMode(id, true)
                Thread.sleep(2000)
                cm.setTorchMode(id, false)
            } catch (e: Exception) {}
        }.start()
    }

    // ---------------- radios ----------------
    @Suppress("DEPRECATION")
    fun wifi(ctx: Context, on: Boolean): Boolean = try {
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).setWifiEnabled(on)
    } catch (e: Exception) { false }

    @Suppress("DEPRECATION")
    fun bluetooth(ctx: Context, on: Boolean): Boolean = try {
        val a = BluetoothAdapter.getDefaultAdapter()
        if (a == null) false else if (on) a.enable() else a.disable()
    } catch (e: Exception) { false }

    // ---------------- status ----------------
    fun systemStatus(ctx: Context): String {
        val sb = StringBuilder()
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val pct = if (lv >= 0) lv * 100 / sc else -1
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10
            sb.append("باتری ${Fa.numWords(pct)} درصد است و ")
            sb.append(if (charging) "در حال شارژ است. " else "شارژ نمی‌شود. ")
            sb.append("دمای باتری ${Fa.numWords(temp)} درجه است. ")
        }
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val free = (mi.availMem / 1073741824.0)
            val tot = (mi.totalMem / 1073741824.0)
            sb.append("از ${Fa.numWords(Math.round(tot).toInt())} گیگابایت حافظه‌ی رم، حدود ${Fa.numWords(Math.round(free * 10).toInt() / 10)} و ${Fa.numWords(Math.round(free * 10).toInt() % 10)} دهم گیگابایت آزاد است. ")
        } catch (e: Exception) {}
        try {
            val sf = StatFs(Environment.getDataDirectory().path)
            val freeG = sf.availableBytes / 1073741824L
            sb.append("حافظه‌ی داخلی ${Fa.numWords(freeG.toInt())} گیگابایت فضای خالی دارد. ")
        } catch (e: Exception) {}
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            sb.append(
                when {
                    caps == null -> "به هیچ شبکه‌ای وصل نیستید. "
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "به وای‌فای وصل هستید. "
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "از اینترنت همراه استفاده می‌کنید. "
                    else -> ""
                }
            )
        } catch (e: Exception) {}
        sb.append(Fa.timeSentence())
        return sb.toString()
    }

    fun signalStatus(ctx: Context): String {
        return try {
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val ss = if (Build.VERSION.SDK_INT >= 28) tm.signalStrength else null
            val level = ss?.level ?: return "نتونستم قدرت سیگنال رو بخونم. اجازه‌ی تلفن رو بررسی کن"
            var dbm: Int? = null
            if (Build.VERSION.SDK_INT >= 29) dbm = ss.cellSignalStrengths.firstOrNull()?.dbm
            val pct = when (level) { 0 -> 5; 1 -> 25; 2 -> 50; 3 -> 75; else -> 100 }
            val q = when (level) { 0 -> "تقریباً آنتن ندارید"; 1 -> "ضعیف است"; 2 -> "متوسط است"; 3 -> "خوب است"; else -> "عالی است" }
            "قدرت سیگنال حدود ${Fa.numWords(pct)} درصد است و $q" +
                if (dbm != null && dbm < 0) ". توان سیگنال منفی ${Fa.numWords(-dbm)} دسی‌بل میلی‌وات است" else ""
        } catch (e: Exception) { "نتونستم سیگنال رو بخونم" }
    }

    // ---------------- location ----------------
    fun locate(ctx: Context, cb: (Location?) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var done = false
            fun finish(l: Location?) { if (!done) { done = true; main.post { cb(l) } } }
            fun fallback(): Location? {
                var best: Location? = null
                for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                    try {
                        val l = lm.getLastKnownLocation(p)
                        if (l != null && (best == null || l.time > best!!.time)) best = l
                    } catch (e: SecurityException) {}
                }
                return best
            }
            main.postDelayed({ finish(fallback()) }, 22000)
            val provider = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(ctx)) { l -> finish(l ?: fallback()) }
            } else {
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(provider, { l -> finish(l) }, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            cb(null)
        }
    }

    // ---------------- apps ----------------
    class AppInfo(val label: String, val pkg: String, val norm: String, val skel: String)

    private var appCache: List<AppInfo> = emptyList()
    private var appT = 0L

    private val letters = mapOf(
        'ب' to 'b', 'پ' to 'p', 'ت' to 't', 'ط' to 't', 'ث' to 's', 'ص' to 's', 'س' to 's', 'ج' to 'j', 'چ' to 'c',
        'ح' to 'h', 'ه' to 'h', 'خ' to 'k', 'د' to 'd', 'ذ' to 'z', 'ز' to 'z', 'ض' to 'z', 'ظ' to 'z', 'ر' to 'r',
        'ژ' to 'j', 'ش' to 's', 'غ' to 'g', 'ق' to 'g', 'ف' to 'f', 'ک' to 'k', 'گ' to 'g', 'ل' to 'l', 'م' to 'm', 'ن' to 'n'
    )

    fun skelFa(s: String): String {
        val sb = StringBuilder()
        for (c in s) { val m = letters[c]; if (m != null && (sb.isEmpty() || sb.last() != m)) sb.append(m) }
        return sb.toString()
    }

    fun skelLatin(s0: String): String {
        var s = s0.lowercase().replace("kh", "k").replace("sh", "s").replace("ch", "c").replace("ph", "f").replace("th", "t")
            .replace("gh", "g").replace("ck", "k").replace("q", "g").replace("x", "ks")
        val sb = StringBuilder()
        for (c in s) {
            if (c !in 'a'..'z') continue
            if (c in "aeiouywv") continue
            val m = when (c) { 'x' -> 'k'; 'q' -> 'g'; else -> c }
            if (sb.isEmpty() || sb.last() != m) sb.append(m)
        }
        return sb.toString()
    }

    private val alias = mapOf(
        "اینستاگرام" to "instagram", "اینستا" to "instagram", "تلگرام" to "telegram", "واتساپ" to "whatsapp", "واتس اپ" to "whatsapp",
        "یوتیوب" to "youtube", "کروم" to "chrome", "دوربین" to "camera", "تنظیمات" to "settings", "گالری" to "gallery",
        "ماشین حساب" to "calc", "نقشه" to "maps", "گوگل" to "google", "ایتا" to "eitaa", "روبیکا" to "rubika", "بله" to "bale",
        "سروش" to "soroush", "اسنپ" to "snapp", "تپسی" to "tap30", "دیجی کالا" to "digikala", "بازار" to "bazaar",
        "مایکت" to "myket", "ساعت" to "clock", "تقویم" to "calendar", "مخاطبین" to "contacts", "پیام" to "messag",
        "تماس" to "dialer", "فایل" to "files", "موزیک" to "music", "اسپاتیفای" to "spotify", "فیسبوک" to "facebook",
        "توییتر" to "twitter", "تیک تاک" to "tiktok", "اسنپ چت" to "snapchat", "نت فلیکس" to "netflix", "شیر ایت" to "shareit",
        "ام ایکس پلیر" to "mxplayer", "ویدیو" to "video", "ضبط صدا" to "recorder", "یادداشت" to "notes", "هوا" to "weather",
        "پلی استور" to "vending", "گوگل پلی" to "vending", "کیبورد" to "keyboard", "بانک" to "bank"
    )

    fun apps(ctx: Context): List<AppInfo> {
        if (System.currentTimeMillis() - appT < 120000 && appCache.isNotEmpty()) return appCache
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<AppInfo>()
        for (ri in pm.queryIntentActivities(i, 0)) {
            val label = ri.loadLabel(pm).toString()
            out.add(AppInfo(label, ri.activityInfo.packageName, Fa.norm(label), skelLatin(label)))
        }
        appCache = out
        appT = System.currentTimeMillis()
        return out
    }

    /** Finds an installed app from the spoken name (Persian label, or an English label spoken in Persian). */
    fun findApp(ctx: Context, spoken0: String): AppInfo? {
        val spoken = Fa.norm(spoken0).removePrefix("برنامه ").removePrefix("اپلیکیشن ").removePrefix("اپ ").trim()
        if (spoken.isEmpty()) return null
        val list = apps(ctx)
        var best: AppInfo? = null
        var bs = 0.0
        val al = alias[spoken]
        val sk = skelFa(spoken.replace(" ", ""))
        for (a in list) {
            var s = Fa.sim(spoken, a.norm)
            if (a.norm.isNotEmpty() && (a.norm == spoken)) s = 1.0
            if (al != null && (a.label.lowercase().contains(al) || a.pkg.lowercase().contains(al))) s = maxOf(s, 0.99)
            if (sk.length >= 3 && a.skel.length >= 3) {
                val ss = Fa.sim(sk, a.skel)
                if (ss >= 0.75) s = maxOf(s, ss * 0.97)
            }
            if (s > bs) { bs = s; best = a }
        }
        return if (best != null && bs >= 0.72) best else null
    }

    fun openApp(ctx: Context, a: AppInfo): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg) ?: return false
        launch(ctx, i)
        return true
    }
}
