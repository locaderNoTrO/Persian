package ir.notro.live

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

/** Offline Persian text to speech through the phone's installed TTS engine (deep, heavy voice). */
class Speaker(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    @Volatile var ready = false
    @Volatile var persianOk = false
    private val callbacks = HashMap<String, () -> Unit>()
    private var counter = 0

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val t = tts!!
                var r = t.setLanguage(Locale("fa", "IR"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    r = t.setLanguage(Locale("fa"))
                }
                persianOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                t.setPitch(0.62f)
                t.setSpeechRate(0.88f)
                t.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { fire(id) }
                    @Deprecated("old api") override fun onError(id: String?) { fire(id) }
                    override fun onError(id: String?, code: Int) { fire(id) }
                })
                ready = true
            }
        }
    }

    private fun fire(id: String?) {
        val cb = synchronized(callbacks) { callbacks.remove(id) }
        cb?.invoke()
    }

    fun speak(text: String, done: () -> Unit) {
        if (SherpaVoice.ready && text.isNotBlank()) {
            Thread {
                try { SherpaVoice.speakBlocking(text) } catch (e: Throwable) {}
                done()
            }.start()
            return
        }
        val t = tts
        if (t == null || !ready || !persianOk || text.isBlank()) {
            // no Persian voice: show the text and use a beep so the assistant is never silent
            if (text.isNotBlank()) {
                try { android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(ctx, text, Toast.LENGTH_LONG).show() } } catch (e: Exception) {}
                Synth.ack()
            }
            done()
            return
        }
        val id = "u" + (counter++)
        synchronized(callbacks) { callbacks[id] = done }
        val p = Bundle()
        val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, p, id)
        if (r != TextToSpeech.SUCCESS) fire(id)
    }

    fun stop() { SherpaVoice.stop(); try { tts?.stop() } catch (e: Exception) {} }
    fun shutdown() { try { tts?.shutdown() } catch (e: Exception) {} }
}
