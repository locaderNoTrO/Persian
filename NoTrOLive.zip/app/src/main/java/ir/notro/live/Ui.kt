package ir.notro.live

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

const val ACID = 0xFFB6FF00.toInt()
const val ACID_SOFT = 0xFFD9FF6B.toInt()
const val BG = 0xFFF2FFC2.toInt()
const val INK = 0xFF132100.toInt()
const val DEEP = 0xFF3A7D00.toInt()

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke > 0) setStroke(dp(stroke), strokeColor)
    }

fun Context.neonButton(text: String, size: Float = 17f, primary: Boolean = true): Button =
    Button(this).apply {
        this.text = text
        textSize = size
        setTextColor(INK)
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        background = rounded(if (primary) ACID else Color.WHITE, 16, 2, DEEP)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        stateListAnimator = null
        elevation = dp(2).toFloat()
    }

fun Context.label(text: String, size: Float = 15f, color: Int = INK, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        setLineSpacing(0f, 1.3f)
    }

fun Context.card(): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Color.WHITE, 18, 2, ACID)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        gravity = Gravity.START
    }
