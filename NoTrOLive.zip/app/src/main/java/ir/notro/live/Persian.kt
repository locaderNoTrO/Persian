package ir.notro.live

import java.util.Calendar

/** Persian text helpers: normalisation, fuzzy matching, colloquial -> formal, numbers, Jalali date. */
object Fa {
    private val diacritics = Regex("[ً-ٰٟـ]")
    private val junk = Regex("[^\\p{L}\\p{N} ]")
    private val spaces = Regex("\\s+")

    fun norm(s: String): String {
        var t = s.replace('ي', 'ی').replace('ك', 'ک').replace('ة', 'ه').replace('ۀ', 'ه')
            .replace('أ', 'ا').replace('إ', 'ا').replace("‌", " ").replace("‏", "")
        t = diacritics.replace(t, "")
        val sb = StringBuilder()
        for (c in t) {
            when (c) {
                in '۰'..'۹' -> sb.append('0' + (c - '۰'))
                in '٠'..'٩' -> sb.append('0' + (c - '٠'))
                else -> sb.append(c)
            }
        }
        t = junk.replace(sb.toString(), " ").lowercase()
        return spaces.replace(t, " ").trim()
    }

    fun words(s: String): List<String> = norm(s).split(" ").filter { it.isNotEmpty() }

    fun edit(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    fun sim(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        if (m == 0) return 1.0
        return 1.0 - edit(a, b).toDouble() / m
    }

    // ---------- colloquial -> formal ----------
    private val colloquial = mapOf(
        "میخوام" to "می‌خواهم", "میخوای" to "می‌خواهی", "میخواد" to "می‌خواهد", "میخوایم" to "می‌خواهیم",
        "نمیخوام" to "نمی‌خواهم", "نمیخوای" to "نمی‌خواهی", "نمیخواد" to "نمی‌خواهد",
        "میدونم" to "می‌دانم", "نمیدونم" to "نمی‌دانم", "میدونی" to "می‌دانی", "نمیدونی" to "نمی‌دانی",
        "میشه" to "می‌شود", "نمیشه" to "نمی‌شود", "میره" to "می‌رود", "میرم" to "می‌روم", "میری" to "می‌روی",
        "میریم" to "می‌رویم", "میاد" to "می‌آید", "میام" to "می‌آیم", "میای" to "می‌آیی", "اومد" to "آمد",
        "اومدم" to "آمدم", "اومدی" to "آمدی", "میگم" to "می‌گویم", "میگی" to "می‌گویی", "میگه" to "می‌گوید",
        "میکنم" to "می‌کنم", "میکنی" to "می‌کنی", "میکنه" to "می‌کند", "میکنیم" to "می‌کنیم",
        "میبینم" to "می‌بینم", "میبینی" to "می‌بینی", "میدم" to "می‌دهم", "میدی" to "می‌دهی", "میده" to "می‌دهد",
        "میگیرم" to "می‌گیرم", "میخورم" to "می‌خورم", "میخوری" to "می‌خوری", "میتونم" to "می‌توانم",
        "میتونی" to "می‌توانی", "میتونه" to "می‌تواند", "نمیتونم" to "نمی‌توانم", "نمیتونی" to "نمی‌توانی",
        "بتونم" to "بتوانم", "بتونی" to "بتوانی", "بدونم" to "بدانم", "بدونی" to "بدانی",
        "اونجا" to "آنجا", "اونجا" to "آنجا", "اونو" to "آن را", "اون" to "آن", "اونا" to "آنها", "اینا" to "اینها",
        "چیه" to "چیست", "کیه" to "کیست", "کجاست" to "کجاست", "چطوری" to "چطور هستی", "چطورین" to "چطور هستید",
        "خوبه" to "خوب است", "بده" to "بد است", "دیره" to "دیر است", "زوده" to "زود است", "درسته" to "درست است",
        "قشنگه" to "زیبا است", "سخته" to "سخت است", "آسونه" to "آسان است", "گرونه" to "گران است",
        "ارزونه" to "ارزان است", "خوشگله" to "زیبا است", "باحاله" to "جالب است", "جالبه" to "جالب است",
        "نیستش" to "نیست", "هستش" to "هست", "خونه" to "خانه", "نون" to "نان", "دونه" to "دانه", "یه" to "یک",
        "رو" to "را", "باهام" to "با من", "باهاش" to "با او", "بهم" to "به من", "بهش" to "به او", "برام" to "برای من",
        "برات" to "برای تو", "واسه" to "برای", "واسم" to "برای من", "واست" to "برای تو", "الان" to "اکنون",
        "خیلی" to "بسیار", "آره" to "بله", "اره" to "بله", "نه" to "نه", "ببخشید" to "ببخشید", "چرا" to "چرا",
        "همچین" to "چنین", "همینجا" to "همین جا", "اینجوری" to "این‌گونه", "اونجوری" to "آن‌گونه",
        "چجوری" to "چگونه", "چطور" to "چطور", "چقدر" to "چقدر", "چیکار" to "چه کار", "چیکارا" to "چه کارها",
        "کاری" to "کاری", "بریم" to "برویم", "بیایم" to "بیاییم", "بگیم" to "بگوییم", "بخوریم" to "بخوریم",
        "بدم" to "بدهم", "بدی" to "بدهی", "بده" to "بده", "بیار" to "بیاور", "ببر" to "ببر", "بزار" to "بگذار",
        "بذار" to "بگذار", "نزار" to "نگذار", "نذار" to "نگذار", "گذاشتم" to "گذاشتم", "گذاشتی" to "گذاشتی",
        "بگو" to "بگو", "بهت" to "به تو", "ازت" to "از تو", "ازم" to "از من", "ازش" to "از او", "دوستت" to "دوستت",
        "اینجا" to "اینجا", "دیگه" to "دیگر", "همه‌ش" to "همه‌اش", "همش" to "همه‌اش", "فقط" to "فقط",
        "مثلا" to "مثلاً", "بعدا" to "بعداً", "حتما" to "حتماً", "واقعا" to "واقعاً", "اصلا" to "اصلاً",
        "تازه" to "تازه", "هنوزم" to "هنوز هم", "اگه" to "اگر", "وگرنه" to "وگرنه", "ولی" to "ولی", "پس" to "پس",
        "چون" to "چون", "آخه" to "آخر", "حالا" to "حالا", "یواش" to "آهسته", "زود" to "زود", "اینقدر" to "این قدر",
        "انقدر" to "آن قدر", "اینقده" to "این قدر", "کمی" to "کمی", "یکم" to "کمی", "یکمی" to "کمی", "مرسی" to "سپاس",
        "ممنون" to "ممنون", "دمت" to "دمت", "داداش" to "برادر", "آبجی" to "خواهر", "رفیق" to "دوست", "بچه‌ها" to "بچه‌ها",
        "شیطونی" to "شیطنت", "شوخی" to "شوخی", "جون" to "جان", "عزیزم" to "عزیزم", "خودم" to "خودم",
        "سلامتی" to "سلامتی", "مشکلی" to "مشکلی", "نمیدونستم" to "نمی‌دانستم", "میدونستم" to "می‌دانستم",
        "گفتن" to "گفتند", "رفتن" to "رفتند", "اومدن" to "آمدند", "کردن" to "کردند", "داره" to "دارد", "دارن" to "دارند",
        "داشت" to "داشت", "نداره" to "ندارد", "نداشت" to "نداشت", "هست" to "هست", "نیست" to "نیست",
        "بود" to "بود", "بودن" to "بودند", "شد" to "شد", "شده" to "شده", "کرده" to "کرده", "گفته" to "گفته",
        "رفته" to "رفته", "اومده" to "آمده", "نیومده" to "نیامده", "نرفته" to "نرفته", "نگفته" to "نگفته",
        "کنه" to "کند", "بکنه" to "بکند", "بشه" to "بشود", "نشه" to "نشود", "باشه" to "باشد", "نباشه" to "نباشد",
        "بره" to "برود", "بیاد" to "بیاید", "بگه" to "بگوید", "بزنه" to "بزند", "بخونه" to "بخواند",
        "بخون" to "بخوان", "نخون" to "نخوان", "میخونم" to "می‌خوانم", "میخونی" to "می‌خوانی", "میخونه" to "می‌خواند",
        "میرسه" to "می‌رسد", "میرسم" to "می‌رسم", "برسم" to "برسم", "میخوابم" to "می‌خوابم", "میخوابی" to "می‌خوابی",
        "تو" to "تو", "من" to "من", "ما" to "ما", "شما" to "شما", "اینو" to "این را", "اینم" to "این هم",
        "اونم" to "آن هم", "منم" to "من هم", "توام" to "تو هم", "توهم" to "تو هم", "ماهم" to "ما هم", "ایشالا" to "ان‌شاءالله",
        "انشالله" to "ان‌شاءالله", "ایشاالله" to "ان‌شاءالله", "مرسی" to "سپاس"
    )

    fun formalize(text: String): String {
        val ws = norm(text).split(" ").filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        for (w in ws) {
            val m = colloquial[w]
            if (m != null) { out.add(m); continue }
            // generic "می" prefix glued to a verb: میخوره -> می‌خورد-like handled only by attaching the ZWNJ
            if (w.length > 4 && w.startsWith("می") && !w.startsWith("میز") && !w.startsWith("میو") &&
                !w.startsWith("میدان") && !w.startsWith("میلاد") && !w.startsWith("میان") && !w.startsWith("میل")
            ) {
                var v = w.substring(2)
                // colloquial 3rd person endings
                if (v.endsWith("ه") && v.length > 3) v = v.dropLast(1) + "د"
                out.add("می‌$v"); continue
            }
            out.add(w)
        }
        return out.joinToString(" ")
    }

    // ---------- numbers ----------
    private val ones = listOf("صفر", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه", "ده", "یازده",
        "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده")
    private val tens = listOf("", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود")
    private val hund = listOf("", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد")

    fun numWords(n0: Int): String {
        var n = n0
        if (n < 0) return "منفی " + numWords(-n)
        if (n < 20) return ones[n]
        if (n < 100) return tens[n / 10] + if (n % 10 != 0) " و " + ones[n % 10] else ""
        if (n < 1000) return hund[n / 100] + if (n % 100 != 0) " و " + numWords(n % 100) else ""
        if (n < 1000000) {
            val th = n / 1000
            val head = if (th == 1) "هزار" else numWords(th) + " هزار"
            return head + if (n % 1000 != 0) " و " + numWords(n % 1000) else ""
        }
        return n.toString()
    }

    private val digitWords = mapOf("صفر" to '0', "یک" to '1', "دو" to '2', "سه" to '3', "چهار" to '4', "پنج" to '5',
        "شش" to '6', "شیش" to '6', "هفت" to '7', "هشت" to '8', "نه" to '9')

    /** "صفر نه یک دو ..." or "0912..." -> digits (null if fewer than 7 digits). */
    fun spokenNumber(t: String): String? {
        val sb = StringBuilder()
        for (w in t.split(" ")) {
            if (w.all { it.isDigit() } && w.isNotEmpty()) sb.append(w)
            else digitWords[w]?.let { sb.append(it) }
        }
        return if (sb.length >= 7) sb.toString() else null
    }

    // ---------- Jalali date ----------
    fun toJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
        val jm: Int
        val jd: Int
        if (days < 186) { jm = 1 + days / 31; jd = 1 + (days % 31) } else { jm = 7 + (days - 186) / 30; jd = 1 + ((days - 186) % 30) }
        return Triple(jy, jm, jd)
    }

    private val months = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
    private val dows = listOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")

    fun dateSentence(c: Calendar = Calendar.getInstance()): String {
        val j = toJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        val dow = dows[c.get(Calendar.DAY_OF_WEEK) - 1]
        return "امروز $dow ${numWords(j.third)} ${months[j.second - 1]} ${numWords(j.first)} است"
    }

    fun timeSentence(c: Calendar = Calendar.getInstance()): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val part = when {
            h < 5 -> "بامداد"; h < 12 -> "صبح"; h < 17 -> "بعد از ظهر"; h < 20 -> "عصر"; else -> "شب"
        }
        val mm = if (m == 0) "" else " و ${numWords(m)} دقیقه"
        return "ساعت ${numWords(h12)}$mm $part است"
    }
}

/** Wake word detection: any word that sounds like نوترو, نوترون or سرهنگ. */
object Wake {
    private val exact = setOf(
        "نوترو", "نوترون", "سرهنگ", "نوتر", "نوترا", "نوتره", "نوتری", "نوتروو", "نوتورو", "نودرو", "ناترو",
        "نیترو", "نوتورون", "نوتور", "نوتروئن", "نوترونن", "نوتروم", "نوترون", "نوتروا", "نوتروی", "نوتروع",
        "نوتل", "نودو", "نوترل"
    )

    private fun hit(c: String): Boolean {
        if (c in exact) return true
        if (c.length >= 4 && (Fa.edit(c, "نوترو") <= 1 || Fa.edit(c, "نوترون") <= 1)) return true
        if (c.length >= 4 && Fa.edit(c, "سرهنگ") <= 1) return true
        return false
    }

    /** Returns the sentence without the wake word, or null when there is no wake word. */
    fun strip(t: String): String? {
        val w = t.split(" ").filter { it.isNotEmpty() }
        var i = 0
        while (i < w.size) {
            // try two words glued together first (e.g. "نو ترو"), then a single word
            if (i + 1 < w.size && hit(w[i] + w[i + 1])) {
                return (w.subList(0, i) + w.subList(i + 2, w.size)).joinToString(" ")
            }
            if (hit(w[i])) {
                return (w.subList(0, i) + w.subList(i + 1, w.size)).joinToString(" ")
            }
            i++
        }
        return null
    }
}
