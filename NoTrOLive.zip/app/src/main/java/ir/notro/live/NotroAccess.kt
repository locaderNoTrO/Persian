package ir.notro.live

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** The "hands" of the assistant: scroll, screenshot, lock, typing, quick-settings toggles, launching apps. */
class NotroAccess : AccessibilityService() {

    companion object {
        @Volatile var inst: NotroAccess? = null
        private val offRe = Regex("(\\boff\\b|خاموش|غیرفعال|غير نشط|إيقاف|معطل)")
        private val onRe = Regex("(\\bon\\b|روشن|فعال|چالو|تشغيل|نشط)")
    }

    private var homePkg: String = ""

    override fun onServiceConnected() {
        inst = this
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            homePkg = packageManager.resolveActivity(i, 0)?.activityInfo?.packageName ?: ""
        } catch (e: Exception) {}
        // make sure the assistant service is running whenever accessibility is on
        try { startAssistant(this) } catch (e: Exception) {}
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = e.packageName?.toString() ?: return
            if (pkg == homePkg) Overlay.setHome(true)
            else if (pkg != "com.android.systemui" && pkg != packageName) Overlay.setHome(false)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        inst = null
        super.onDestroy()
    }

    fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    fun lockScreen(): Boolean = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun screenshot(): Boolean = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    fun swipe(up: Boolean) {
        val dm = resources.displayMetrics
        val p = Path()
        val x = dm.widthPixels / 2f
        if (up) { p.moveTo(x, dm.heightPixels * 0.72f); p.lineTo(x, dm.heightPixels * 0.28f) }
        else { p.moveTo(x, dm.heightPixels * 0.28f); p.lineTo(x, dm.heightPixels * 0.72f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 320)).build()
        dispatchGesture(g, null, null)
    }

    // ---------- typing ----------
    private fun focusedInput(): AccessibilityNodeInfo? =
        try { rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) } catch (e: Exception) { null }

    fun hasInput(): Boolean = focusedInput() != null

    fun fieldText(): String {
        val n = focusedInput() ?: return ""
        if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) return ""
        return n.text?.toString() ?: ""
    }

    fun setFieldText(s: String): Boolean {
        val n = focusedInput() ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        val ok = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        try {
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, s.length)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, s.length)
            n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } catch (e: Exception) {}
        return ok
    }

    // ---------- quick settings ----------
    private fun walk(n: AccessibilityNodeInfo?, depth: Int, f: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null || depth > 25) return null
        if (f(n)) return n
        for (i in 0 until n.childCount) {
            val r = walk(n.getChild(i), depth + 1, f)
            if (r != null) return r
        }
        return null
    }

    private fun descOf(n: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        sb.append(n.text ?: "").append(' ').append(n.contentDescription ?: "")
        if (Build.VERSION.SDK_INT >= 30) sb.append(' ').append(n.stateDescription ?: "")
        return sb.toString().lowercase()
    }

    /** Blocking: call from a background thread. Returns "done", "already" or "notfound". */
    fun toggleQuick(keys: List<String>, wantOn: Boolean): String {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        Thread.sleep(1100)
        var result = "notfound"
        for (attempt in 0 until 4) {
            val root = try { rootInActiveWindow } catch (e: Exception) { null }
            if (root != null) {
                val node = walk(root, 0) { nd -> val s = descOf(nd); keys.any { k -> s.contains(k) } }
                if (node != null) {
                    var c: AccessibilityNodeInfo? = node
                    var hops = 0
                    while (c != null && !c.isClickable && hops < 6) { c = c.parent; hops++ }
                    val target = c ?: node
                    val d = descOf(node) + " " + descOf(target)
                    val on = when {
                        offRe.containsMatchIn(d) -> false
                        onRe.containsMatchIn(d) -> true
                        else -> target.isChecked || target.isSelected
                    }
                    if (on != wantOn) { target.performAction(AccessibilityNodeInfo.ACTION_CLICK); result = "done" }
                    else result = "already"
                    break
                }
            }
            Thread.sleep(500)
        }
        Thread.sleep(500)
        performGlobalAction(GLOBAL_ACTION_BACK)
        Thread.sleep(250)
        performGlobalAction(GLOBAL_ACTION_BACK)
        return result
    }
}

fun startAssistant(ctx: android.content.Context) {
    val i = Intent(ctx, AssistantService::class.java)
    if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
}
