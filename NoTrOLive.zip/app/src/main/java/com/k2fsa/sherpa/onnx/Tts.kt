package com.k2fsa.sherpa.onnx

import android.content.res.AssetManager

// Placeholder. The CI build replaces this file with the real sherpa-onnx Tts.kt.
// If the replacement fails, the app still builds and falls back to the phone's own TTS.
data class OfflineTtsVitsModelConfig(var model: String = "", var lexicon: String = "", var tokens: String = "", var dataDir: String = "")
data class OfflineTtsModelConfig(var vits: OfflineTtsVitsModelConfig = OfflineTtsVitsModelConfig(), var numThreads: Int = 1, var debug: Boolean = false, var provider: String = "cpu")
data class OfflineTtsConfig(var model: OfflineTtsModelConfig = OfflineTtsModelConfig())
class GeneratedAudio(val samples: FloatArray, val sampleRate: Int)
class OfflineTts(assetManager: AssetManager? = null, var config: OfflineTtsConfig) {
    init { throw UnsupportedOperationException("sherpa-onnx not bundled") }
    fun generate(text: String, sid: Int = 0, speed: Float = 1.0f): GeneratedAudio = throw UnsupportedOperationException()
    fun release() {}
}
