#!/usr/bin/env python3
"""Builds the offline map data (Iran + Iraq) for NoTrO live from OpenStreetMap extracts.

usage: build_places.py WORKDIR OUT_ASSETS_DIR
needs: osmium-tool, shapely. Expects WORKDIR/iran.pbf and WORKDIR/iraq.pbf
produces: OUT/admin.json  (province + county polygons)  and  OUT/places.db (places + roads)
"""
import json, math, os, sqlite3, subprocess, sys

work, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
COUNTRIES = [("IR", "iran.pbf"), ("IQ", "iraq.pbf")]


def run(*a):
    subprocess.run(list(a), check=True)


def seq(path):
    """yield geojson features from a geojsonseq file"""
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip("\x1e\n\r ")
            if not line:
                continue
            try:
                yield json.loads(line)
            except Exception:
                continue


def nm(tags):
    return (tags.get("name:fa") or tags.get("name") or tags.get("name:ar") or "").strip()


# ------------------------------------------------------------------ admin polygons
def admin(pbf, cc, acc):
    from shapely.geometry import shape
    b = os.path.join(work, cc + "_b.pbf")
    g = os.path.join(work, cc + "_b.geojsonseq")
    run("osmium", "tags-filter", pbf, "r/boundary=administrative", "-o", b, "--overwrite")
    run("osmium", "export", b, "-f", "geojsonseq", "--geometry-types=polygon", "-o", g, "--overwrite")
    for ft in seq(g):
        p = ft.get("properties") or {}
        lvl = p.get("admin_level")
        if lvl not in ("4", "5"):
            continue
        name = nm(p)
        if not name:
            continue
        try:
            geom = shape(ft["geometry"]).simplify(0.002, preserve_topology=True)
        except Exception:
            continue
        polys = [geom] if geom.geom_type == "Polygon" else list(getattr(geom, "geoms", []))
        rings = []
        for pg in polys:
            if pg.geom_type != "Polygon" or pg.is_empty:
                continue
            for r in [pg.exterior] + list(pg.interiors):
                flat = []
                for x, y in r.coords:
                    flat += [round(x, 4), round(y, 4)]
                if len(flat) >= 8:
                    rings.append(flat)
        if not rings:
            continue
        mnx, mny, mxx, mxy = geom.bounds
        acc.append({"l": int(lvl), "c": cc, "n": name, "b": [round(mnx, 4), round(mny, 4), round(mxx, 4), round(mxy, 4)], "r": rings})


# ------------------------------------------------------------------ places and roads
PLACES = "city,town,village,hamlet,suburb,neighbourhood"
MAJOR = {"motorway", "trunk", "primary", "secondary", "tertiary", "motorway_link", "trunk_link", "primary_link"}
MINOR = {"residential", "living_street", "unclassified", "service", "pedestrian", "track", "path"}


def places(pbf, cc, cur):
    p = os.path.join(work, cc + "_p.pbf")
    g = os.path.join(work, cc + "_p.geojsonseq")
    run("osmium", "tags-filter", pbf, "n/place=" + PLACES, "-o", p, "--overwrite")
    run("osmium", "export", p, "-f", "geojsonseq", "--geometry-types=point", "-o", g, "--overwrite")
    rows = []
    for ft in seq(g):
        pr = ft.get("properties") or {}
        kind = pr.get("place")
        name = nm(pr)
        if not name or kind not in PLACES.split(","):
            continue
        lon, lat = ft["geometry"]["coordinates"][:2]
        rows.append((name, kind, round(lat, 5), round(lon, 5)))
    cur.executemany("INSERT INTO places VALUES (?,?,?,?)", rows)


def hav(a, b):
    dy = (a[1] - b[1]) * 111000.0
    dx = (a[0] - b[0]) * 111000.0 * math.cos(math.radians(a[1]))
    return math.hypot(dx, dy)


def roads(pbf, cc, cur):
    r = os.path.join(work, cc + "_r.pbf")
    g = os.path.join(work, cc + "_r.geojsonseq")
    run("osmium", "tags-filter", pbf, "w/highway", "-o", r, "--overwrite")
    run("osmium", "export", r, "-f", "geojsonseq", "--geometry-types=linestring", "-o", g, "--overwrite")
    batch = []
    for ft in seq(g):
        pr = ft.get("properties") or {}
        hw = pr.get("highway")
        name = nm(pr)
        if not name:
            continue
        kind = "major" if hw in MAJOR else ("minor" if hw in MINOR else None)
        if kind is None:
            continue
        step = 150.0 if kind == "major" else 70.0
        pts = ft["geometry"]["coordinates"]
        last = None
        for i, pt in enumerate(pts):
            if last is None or hav(pt, last) >= step or i == len(pts) - 1:
                batch.append((name, kind, round(pt[1], 5), round(pt[0], 5)))
                last = pt
        if len(batch) > 50000:
            cur.executemany("INSERT INTO roads VALUES (?,?,?,?)", batch)
            batch = []
    if batch:
        cur.executemany("INSERT INTO roads VALUES (?,?,?,?)", batch)


def main():
    acc = []
    dbp = os.path.join(out, "places.db")
    if os.path.exists(dbp):
        os.remove(dbp)
    con = sqlite3.connect(dbp)
    cur = con.cursor()
    cur.execute("CREATE TABLE places(name TEXT, kind TEXT, lat REAL, lon REAL)")
    cur.execute("CREATE TABLE roads(name TEXT, kind TEXT, lat REAL, lon REAL)")
    for cc, f in COUNTRIES:
        pbf = os.path.join(work, f)
        if not os.path.exists(pbf):
            print("missing", pbf)
            continue
        print("== admin", cc, flush=True); admin(pbf, cc, acc)
        print("== places", cc, flush=True); places(pbf, cc, cur)
        print("== roads", cc, flush=True); roads(pbf, cc, cur)
        con.commit()
    cur.execute("CREATE INDEX i_p ON places(lat)")
    cur.execute("CREATE INDEX i_r ON roads(lat)")
    con.commit()
    con.execute("VACUUM")
    con.close()
    with open(os.path.join(out, "admin.json"), "w", encoding="utf-8") as f:
        json.dump(acc, f, ensure_ascii=False, separators=(",", ":"))
    print("admin polygons:", len(acc))


if __name__ == "__main__":
    main()
